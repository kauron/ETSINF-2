#include <stdio.h> 
#define SIZE_STRING 200
main() {
    // Character pointers to copy the input string
    char *p1, *p2;

    // A) Define the string variables string and string2 
    
    // B) Read string in the console 
    
    // C) Convert to uppercase
    p1 = string;
    p2 = string2;
    while (*p1 != '\0') {
        // Copy p1 to p2 subtracting 32 if necessary
    }
    // Remember to append the null value at the end of string2
    
    // D) Out in the console string2.
}


